import React from 'react';
import './AppJsx.css';

//JSX는 JavaScript XML의 약자입니다.
//JSX를 사용하면 React에서 HTML을 작성할 수 있습니다.
//JSX를 사용하면 React에서 HTML을 더 쉽게 작성하고 추가할 수 있습니다.
function AppJsx() {

  const myelement1 = <h1>JSX로 작성한 React</h1>;// JSX로 작성

  const myelement2 = (
    <ul>
      <li>apple</li>
      <li>banana</li>
    </ul>

  );

  const myelement3 = React.createElement('h2', {}, 'JSX 없이 사용한 React');//JSX없이 작성

  const name = '이순신';
  let age = 20;
  let adult;
  if (age >= 19) {
    adult = '성년'
  } else {
    adult = '미성년';
  }
  const myelement4 = <span>{name}은 {age}세이고, {adult}입니다</span>;

  const num = 75;
  const myelement5 = <div> {num}은 {num <= 0 ? "0 또는 음수" : "양수"} 입니다</div>

  return (
    <div className="App">
      {myelement1}
      {myelement2}
      {myelement3}
      {myelement4}
      {myelement5}
    </div>
  );
}
//컴포넌트를 다른 곳에서 사용하기 위해서 export default를 한다. 
//이렇게 하면 다른 곳에서 사용할 때, 중괄호 없이 가져온다. 
export default AppJsx;