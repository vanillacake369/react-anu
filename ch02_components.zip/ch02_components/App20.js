import React from 'react';
import MyComp from './example/ex20_useRef';

const App=()=>{
    return (
        <div className="container py-5">
            <MyComp/>
        </div>
    )
} 
export default App;