import React from 'react';
import MyComp from './example/ex13_func'

const App=()=>{
    return (
        <div className="container py-5">
            <MyComp title="재미있는 React" txtColor="red"></MyComp>
            <MyComp title="쉬운 React" txtColor="green"></MyComp>
        </div>
    )
}
export default App;