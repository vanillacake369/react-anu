import React from 'react';
import './App.css'
import MyComp from './example/ex10_lifecycle'
//class로 구현 ==> 함수형도 같이 사용
class App extends React.Component{
  state={
      visible:true
  }
    
  render(){
    //자바스크립트 주석
    return (
    //자바스크립트 영역: 루트 엘리먼트는 반드시 1개 있어야 한다.
    <div className="container">
        <h1>여기는 부모 App</h1>
        {this.state.visible&&<MyComp></MyComp>}  
        <hr></hr>      
        <label><input type="checkbox" onClick={()=>{
            this.setState({visible:!this.state.visible})
        }}></input>자식 컴포넌트 감추기</label>
    </div>
    )  
 }
}
export default App;