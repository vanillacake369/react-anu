import React from 'react';

class Car extends React.Component{
  render() {
    return <h2>리액트를 클래스로 컴포넌트 만들기</h2>
  }
}

export default Car;