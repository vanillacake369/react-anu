import React from 'react';
import './App.css'
import {BrowserRouter} from 'react-router-dom'
import MyComp from './example/ex11_router'
class App extends React.Component{

  render(){

    return (
        <BrowserRouter>
            <MyComp></MyComp>
        </BrowserRouter>
    )  
 }
}
export default App;