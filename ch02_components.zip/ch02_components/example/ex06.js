import React, { Component } from 'react';

class MyComp extends Component {
    state={
        title:'내가 좋아하는 아이돌',
        idols:[
            'BTS','BlackPing','MonstaX','WanaOne'
        ],
        images:[
            'images/bts.png',
            'images/blackpink.png',
            'images/monstax.png',
            'images/wanaone.png'
        ]
    }

    render() {
        //객체 비구조화 할당 (destructuring)
        const {idols, images}=this.state;

        //2. map() 함수를 이용하는 방법
        //배열.map((obj, i)=>{})
        let names=idols.map((val,i)=>{
            return <h2 key={i}>{val}</h2>
        })

        let imgs = images.map((val,i)=>{
            return <img src={val} key={i} alt={val}></img>
        })

        return (
            <div className="container p-5">
                <h1>{this.state.title}</h1>
                {names}
                <hr></hr>
                {imgs}
            </div>
        );
    }
}

export default MyComp;