import React,{useState} from 'react';
const Info=()=>{

    const [name, setName] = useState('');
    const [nick, setNick] = useState('');

    const onChangeName=(e)=>{
        let uname=e.target.value;
        console.log(uname);
        setName(uname);//this.setState({})와 같은 기능
    }

    const onChangeNick=(e)=>{
        setNick(e.target.value);
        //주의 사항. state값을 수정해야 할 때는
        //inputs[name]=value ;식으로 직접 수정하면 안된다.
        //setter를 통해 수정해야 한다.
    }

    return (
        <div>
            <div>
                <h1>여러개의 useState훅 사용</h1>
                <p> useState()는 하나의 상태값만 관리할 수 있다.
                    컴포넌트에서 관리해야 할 상태가 여러 개면 useState()를
                    여러 번 사용한다.
                </p>
                <input type="text" name="name" value={name} placeholder="Name" onChange={onChangeName}></input>
                <br></br>
                <br></br>
                <input type="text" name="nick" value={nick} placeholder="Nick" onChange={onChangeNick}></input>
            </div>
            <hr></hr>
            <div>
                <h1>이름: {name}</h1>
                <h1>닉네임: {nick}</h1>
            </div>
        </div>
    )
}
export default Info;
//export default Info; ==> import Info '모듈'
//export Info  ==> import {Info} from '모듈'