import React from 'react'

const data={
    message:'안녕하세요?'
}

const MyComp=({title, txtColor})=>{
    //console.log(title, txtColor)
    //함수형은 props를 파라미터로 받는다. 이때 destructuring(비구조화)을 이용해서 받는다.

    return (
        <div>
            <h1>MyComp 컴포넌트(함수형 컴포넌트)</h1>
            <h2 style={{color:txtColor}}>{title}</h2>
            <h3 style={{backgroundColor:txtColor, color:'white'}}>{data.message}</h3>
            <hr></hr>
        </div>        
    )
}
export default MyComp;