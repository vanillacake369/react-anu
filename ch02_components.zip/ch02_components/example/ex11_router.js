// ex11_router.js
//react-router-dom
//npm i --s react-router-dom
import React, { Component } from 'react';
import {Route, Link} from 'react-router-dom'

class MyComp extends Component {
    render() {
        return (
            <div className="container p-4">
                <h1>MyComp</h1>
                <hr></hr>
                {/* <a href="/">Home</a> */}
                <Link to="/" className="m-3">Home</Link>
                <Link to="/mypage/swan"  className="m-3">MyPage1</Link>
                <Link to="/mypage/admin"  className="m-3">MyPage2</Link>
                <Link to="/join"  className="m-3">Signup</Link>
                <hr></hr>
                <Route exact path="/" component={Home}></Route>
                <Route path="/mypage/:userid" component={MyPage}></Route>
                <Route path="/join" component={Signup}></Route>
            </div>
        );
    }
}////////////////////////////////

function Home(){
    return (
        <div>
            <h1>Home Page</h1>
        </div>
    )
}


function MyPage({match}){//함수형 컴포넌트
        console.log(match.params)
        const {userid}=match.params;
        return (
            <div>
                <h1 className="text-info">MyPage</h1>
                <h2 className="text-success">{userid}님 페이지</h2>
            </div>
        )
    
}

function Signup(){
    return (
        <div>
            <h1 className="text-danger">Signup</h1>
        </div>
    )
}


export default MyComp;