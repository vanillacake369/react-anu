import React,{useState, useMemo} from 'react';

const getAvg=(arr)=>{
    console.log('평균값 계산 중...');
    let sum=0;
    for(let i=0;i<arr.length;i++){
        sum+=arr[i];
    }
    let avg=sum/arr.length;
    return avg;
}

const MyComp = () => {
    const [num, setNum] = useState('')
    const [list, setList] =useState([]);

    const avg=useMemo(()=>{
        return getAvg(list);
    },[list])
    //[]안의 list의 내용이 바뀌었을 때만 getAvg()함수를 호출한다.
    //useMemo훅을 사용하면 컴포넌트 내부에서 발생하는 연산을 최적화할 수 있다.
    //렌더링 과정에서 특정값이 바뀌었을 때만 연산을 실행하고, 원하는 값의 변경이 없으면 이전 결과를 다시 사용하는 방식

    const handleChange=(e)=>{
        //사용자가 입력한 값을 실시간으로 num에게 전달하기
        setNum(e.target.value)
    }

    const handleAdd=(e)=>{
        //새로 추가한 값(num)을 list에 추가하기
        //let arr=[...list];
        //arr.push(num);
        let arr =[...list, parseInt(num)];
        setList(arr);
        setNum('')
    }


    return (
        <div>
            <input type="text" name="num" value={num} onChange={handleChange}></input>
            <button className="btn" onClick={handleAdd}>등  록</button>
            <ul>
                {
                    list.map((val, i)=>(
                        <li key={i}>{val}</li>
                    ))    
                }
            </ul>
            {/* <h1 className="text-danger">평균값: {getAvg(list)} </h1> */}
            <h1 className="text-primary">평균값:{!isNaN(avg)&&avg}</h1>
        </div>
    );
};

export default MyComp;