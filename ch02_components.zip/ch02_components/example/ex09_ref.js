import React, { Component } from 'react';

class MyTextInput extends Component {

    txt1=React.createRef();
    //DOM을 참조하려면 React.createRef()를 통해 ref객체를 얻는다.
    txt2=React.createRef();

    state={
        userid:'',
        pwd:''
    }

    handleChange=(e)=>{
        this.setState({[e.target.name]:e.target.value})
    }
    componentDidMount(){
        console.log('componentDidMount')
        //dom이 mount되고 난 후에 호출되는 함수
        this.setFocus();
    }
    setFocus=()=>{
        //alert('focus처리 예정')
        this.txt1.current.focus();
        //this.txt2.current.focus();
        //ref객체의 current속성을 사용하여 명시적으로 txt1이 참조하는
        //input에 포커스를 준다.
    }

    render() {
        const {userid,pwd} = this.state;
        return (
            <div style={{padding:'3em'}}>
                <label>아이디:</label>
                <input type="text" ref={this.txt1}
                name="userid" placeholder="User ID" value={userid} className="form-control"
                onChange={this.handleChange}></input>

                <label>비밀번호:</label>
                <input type="password" ref={this.txt2}
                name="pwd" placeholder="Password"  value={pwd}
                className="form-control"
                onChange={this.handleChange}></input>
                <button className="btn btn-primary btn-block">로그인</button>
            </div>
        );
    }
}

export default MyTextInput;