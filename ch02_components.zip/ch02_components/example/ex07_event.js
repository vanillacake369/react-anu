import React, { Component } from 'react';
/* 이벤트 사용시 주의 사항
1. 이벤트 이름은 camel표기법으로 작성한다.
    ex)html=> onclick
       React=> onClick
2. 이벤트에 실행할 자바스크립트 코드를 전달하는 것이 아니라,
   함수형태의 값을 전달한다.
3. DOM요소에만 이벤트를 설정할 수 있다.
    button, input, div,... => 이벤트 설정 가능
    MyComp =>우리가 직접 만든 컴포넌트에는 자체적으로 이벤트 설정을 할 수 없다.
            => 만약 MyComp에 onClick을 설정한다면 이것은 이벤트가 아니라 props를
            MyComp에게 전달하는 것이
*/

class MyComp extends Component {
    state={
        msg:''
    }
    handleChange(e){
        this.setState({msg:e.target.value})
    }
    handleChange2=(e)=>{
        this.setState({msg:e.target.value})
    }
    //handleClick함수 작성하기 => msg값을 초기화 ''
    handleClick=()=>{
        this.setState({msg:''})   
    }

    handleKeyPress=(e)=>{
        //console.log(e.key)
        if(e.key ==='Enter'){
            this.handleClick();
        }
    }

    render() {
        const {msg} =this.state;
        const {onClick}=this.props;
        return (
            <div>
                <h1>이벤트 처리</h1>
                <h2 className="text-primary">{onClick}</h2>
                <h2 className="text-danger">{msg}</h2>
                <input name="message" placeholder="Message" onChange={this.handleChange2} value={msg} onKeyPress={this.handleKeyPress}></input>
                <button className="btn btn-success" onClick={this.handleClick}>Send</button>
            </div>
        );
    }
}

export default MyComp;