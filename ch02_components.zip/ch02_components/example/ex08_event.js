import React, { Component } from 'react';

class MyComp extends Component {
    state={
        userName:'',
        userid:'',
        pwd:''
    }
    handleChange=(e)=>{
        //this.setState({userName:e.target.value})
        //e.target.name ==> input name 이 들어옴
        //e.target.value==> 사용자가 입력한 값이 들어옴
        //console.log(e.target.name+"/"+e.target.value)
        this.setState({
            [e.target.name]:e.target.value
        })
    }

    render() {
        const {userName, userid, pwd}=this.state;
        return (
            <div>
                <h1>Input 여러 개 다룰 때 이벤트 처리</h1>
                <label>이름:</label>
                <input type="text" name="userName" placeholder="Name" value={userName} className="form-control" onChange={this.handleChange}></input>

                <label>아이디:</label>
                <input type="text" name="userid" placeholder="User ID" value={userid} className="form-control"
                onChange={this.handleChange}></input>

                <label>비밀번호:</label>
                <input type="password" name="pwd" placeholder="Password"  value={pwd}
                className="form-control"
                onChange={this.handleChange}></input>
                <button className="btn btn-primary btn-block">회원  가입</button>

                <hr></hr>
                <h2>이    름: {userName} </h2>
                <h2>아 이 디: {userid} </h2>
                <h2>비밀번호: {pwd} </h2>
            </div>
        );
    }
}

export default MyComp;