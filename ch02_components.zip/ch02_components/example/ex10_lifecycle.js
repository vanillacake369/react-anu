import React, { Component } from 'react';

class MyComp extends Component {
    

    //1. 생성자
    constructor(props){
        super(props);
        this.state={
            hidden:false,
            mycolor:'tomato'
        }
        console.log('1. constructor...')
    }

    //2. props로 받아온 값을 state에 적용할 때 호출된다.
    //컴포넌트가 마운트 될 때와 업데이트 될 때 호출된다.
    static getDerivedStateFromProps(nextProps, prevState){
        console.log('2. getDerivedStateFromProps...')
        return null;
        //state를 변경할 필요가 없다면 null을 반환
    }
   
    onClickBtn = ()=>{
        //hidden값을 false로 변경1
        //this.setState({hidden:false})
        this.setState({hidden:!this.state.hidden})
    }

    //3. UI를 화면에 렌더링하는 함수
    render() {
        console.log('3. render')
        const {mycolor, hidden} = this.state;
        return (
            <div>
                {!hidden&&<h1 style={{color:mycolor}}>I am a MyComp</h1>}

                <button className="btn btn-info" onClick={this.onClickBtn}>Hide</button>
                <button className="btn btn-warning" onClick={this.onClickBtn}>Show</button>
            </div>
        );
    }

    //4. 컴포넌트가 웹브라우저상에 나타난 후 호출되는 메소드
    componentDidMount(){
        console.log('4. componentDidMount...')
    }

    //수정시 render하기 전에 호출되는 함수. 이 함수에서 true를 반환하면
     //render를 호출하고, false를 반환하면 render를 취소한다.
     //성능 최적화하고자 할 때 사용
    shouldComponentUpdate(){
        console.log('update 2: shouldComponentUpdate')
        //return true;
        return (this.state.mycolor==='tomato')? true:false;
    }

    //수정되기 전의 props나 state값 들의 정보를 얻을 수 있는 함
    getSnapshotBeforeUpdate(prevProps, prevState){
        console.log('update 4 : prevState.hidden==>'+prevState.hidden)
        return null;
    }

    componentDidUpdate(prevProps, prevState, snapshot){
        console.log('update 5:  componentDidUpdate', prevProps, prevState)
        if(snapshot){
            console.log('snapshot: ', snapshot)
        }
    }
    //데이터가 수정될 때 호출되는 함수
    //1. getDerivedStateFromProps
    //2. shouldComponentUpdate
    //3. render
    //4. getSnapshotBeforeUpdate
    //5. componentDisUpdate

    
    //컴포넌트가 제거될 때 호출되는 함수
    //componentWillUnmount()
    //컴포넌트를 DOM에서 제거할 때 실행된다.
    componentWillUnmount(){
        console.log('delete componentWillUnmount()')
    }
}

export default MyComp;