import React, {useState, useEffect} from 'react';
import axios from 'axios';
const fetchBoardData=(callback)=>{
    let url="/react_memo/list.jsp";
    axios.get(url)
         .then((res)=>{
            //alert(res.data);
            //setBoardList(res.data);
            callback(res.data)
         })
         .catch((err)=>{
             alert('error: '+err.message);
         })

}//------------------------------


const BoardApp = () => {

    // const fetchBoardData=()=>{
    // let url="/react_memo/list.jsp";
    // axios.get(url)
    //      .then((res)=>{
    //         //alert(res.data);
    //         setBoardList(res.data);
    //      })
    //      .catch((err)=>{
    //          alert('error: '+err.message);
    //      })

    // }


    const boards=[
        {idx:1, title:'이건 제목1', name:'홍길동',wdate:'21-08-30'},
        {idx:2, title:'이건 제목2', name:'김길동',wdate:'21-08-20'},
        {idx:3, title:'이건 제목3', name:'임길동',wdate:'21-08-10'}
    ]
    const initValue = [];
    const [boardList, setBoardList] = useState(initValue);
    initValue.push(...boards);

    useEffect(()=>{
        //componentDidMount()/componentDidUpdate() 
        console.log('useEffect()...')
        //ajax요청 처리를 여기에서
        //fetchBoardData();
        fetchBoardData((data)=>{
            //alert("fetachBoardData안의 콜백함수: "+data)
            setBoardList(data);
        })

    },[boardList])
    //useEffect()훅은 기본적으로 렌더링 되고 난 직후마다 실행되며,
    //두번째 파라미터 배열에 무엇을 넣었는지 따라 실행조건이 달라진다.
    //DOM이 메모리에 올라오고 한번만 호출하고 싶다면  빈배열[]을 2번째 파라미터로 전달


    const handleClick=()=>{
        let arr=[... initValue];
        arr.push({idx:4, title:"제목4",name:"최길동", wdate:'21-10-01'})
        setBoardList(arr)
    }

    return (
        <div className="container p-5">
            <h1>게시판</h1>
            <button className="btn btn-success m-5" onClick={handleClick}>Add</button>

            <ul className="list-group">
            {boardList.map((board, i)=>{
                return (
                <li className="list-group-item" key={board.idx}>
                    <a href='#'>{board.title}</a>
                    <span className="float-right">{board.name}[{board.wdate}]</span>
                </li>
                )
            })
            }
            </ul>
            
        </div>
    );
};

export default BoardApp;