import React from 'react';

class MyComp extends React.Component{
    constructor(props){
        super(props);
        //반드시 super를 호출하여 props값을 전달해야 한다.
        console.dir(props);
        //props는 readony(읽기 전용)=> props값을 수정하려고 하면 안된다.
    }
    render(){
        let mystyle={
            color:'maroon',
            backgroundColor:'beige'
        }

        return (
            <div style={{padding:'5em',backgroundColor:'aqua'}}>
                <h1 style={mystyle}>{this.props.title}</h1>
            </div>
        )
    }

}
export default MyComp;