import React, { Component } from 'react';

class MyComp extends Component {

    state={
        items:[
            '오늘은 기쁜 날입니다',
            '내일도 행복할거에요',
            '즐거운 하루 되세요'
        ],
        title:'React Test'
    }

    render() {
        //객체 비구조화 할당 (destructuring)
        const {title, items}=this.state;

        //1. 고전적인 for루프 이용방법
        //반복문 이용시 반드시 key속성에 유니크한 값을 지정해야 한다.
        let str=[];
        for(let i=0;i<items.length;i++){
            str.push(<h2 key={i}>{items[i]}</h2>)
        }
        //2. map() 함수를 이용하는 방법
        //배열.map((obj, i)=>{})
        let str2=items.map((obj, i)=>{
            return <h2 key={i} className="text-primary">{obj}</h2>
        })


        return (
            <div className="container p-5">
                <h1>{title}</h1>
                {str}  {str2}
            </div> 
        );
    }
}

export default MyComp;