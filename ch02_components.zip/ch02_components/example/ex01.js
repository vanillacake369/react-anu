import React from 'react';

class MyComp extends React.Component {

    constructor(props) {
        super(props);
        console.log('props.title : ' + props.title + ", " + this.props.children);
    }

    render() {

        return (
            <div>
                <h1 style={{ color: this.props.mycolor }}>MyComp {this.props.title}</h1>
                <h2>{this.props.mycolor} {this.props.children} </h2>
            </div>
        )
    }

}
export default MyComp;

//Props개념
//React가 컴포넌트로 작성한 엘리먼트를 발견하면 JSX어트리뷰트와 자식을 해당 컴포넌트에 단일 객체로 전송한다.
//이 객체를 "props"(properties의 약자)라고 한다. 즉 부모컴포넌트에서 자식컴포넌트로 전달해주는 객체이다