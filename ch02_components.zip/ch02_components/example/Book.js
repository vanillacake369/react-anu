import React, { Component } from 'react';
import '../App.css'
class Book extends Component {
    render() {
        const {title, link, image}=this.props;
        console.log(link)
        return (
            <div className="col-md-3 m-2 p-2">
                <img src={image} className="img-fluid-block" alt="도서 이미지"></img>
                <h3>{title}</h3>
                <button className="btn btn-outline-danger">Info</button>
            </div>
        );
    }
}

export default Book;