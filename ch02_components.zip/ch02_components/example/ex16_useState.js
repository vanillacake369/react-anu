import React, {useState} from 'react';

const BoardApp = ({mainTitle}) => {
    const boards=[
        {idx:1, title:'이건 제목1', name:'홍길동',wdate:'21-08-30'},
        {idx:2, title:'이건 제목2', name:'김길동',wdate:'21-08-20'},
        {idx:3, title:'이건 제목3', name:'임길동',wdate:'21-08-10'}
    ]
    const initValue = [];
    const [boardList, setBoardList] = useState(initValue);
    initValue.push(...boards);

    const handleClick=()=>{
        let arr=[... initValue];
        arr.push({idx:4, title:"제목4",name:"최길동", wdate:'21-10-01'})
        setBoardList(arr)
    }

    return (
        <div className="container p-5">
            <h1>{mainTitle}</h1>
            <button className="btn btn-success m-5" onClick={handleClick}>Add</button>

            <ul className="list-group">
            {boardList.map((board, i)=>{
                return (
                <li className="list-group-item" key={board.idx}>
                    <a href='#'>{board.title}</a>
                    <span className="float-right">{board.name}[{board.wdate}]</span>
                </li>
                )
            })
            }
            </ul>
            
        </div>
    );
};

export default BoardApp;