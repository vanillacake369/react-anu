import React,{useState} from 'react';
/**
 * useState훅은 함수형 컴포넌트에서도 상태(state)관리를
 * 할 수 있도록 해주는 내장 훅 함수이다.
 * 
 * const [value, setValue]=useState('디폴트값')
 * 형태로 사용한다.
 */

const Counter = () => {
    let style={
        backgroundColor:'skyblue',
        width:'100px',
        height:'100px',
        padding:'1.5em',
        borderRadius:'50%',
        textAlign:'center',
        margin:'1em auto'
    }

    const [count, setCount] = useState(10);

    const increase =()=>{
        setCount(count+1);
    }

    const decrease =()=>{
        setCount(count-1);
    }

    return (
        <div className="text-center">
            <div style={style}>
                <h1>{count}</h1>
            </div>
            <button className="btn btn-success" onClick={increase}>증가(+)</button>
            <button className="btn btn-danger" onClick={decrease}>감소(-)</button>
        </div>
    );
};

export default Counter;