//npm i --s axios
import React, { Component } from 'react';
import Book from './Book';
import axios from 'axios';

class BookApp extends Component {

    state={
        books:[],
        scrollTop:0,
        items:1,
        preItems:1,
        loading:false,
        count:0
    }

    componentDidMount(){
        window.addEventListener('scroll', this.onScroll)
        //ajax요청을 보내자.
        //setTimeout(()=>{
           this.getBookData(this.state.preItems); 
        //}, 2000);
    }

    shouldComponentUpdate(nextProps, nextState) {
    //example 특정컴포넌트의 최상단(top)이 스크롤하여 가려져서 안보이게 되면(top<0) 특정 액션 실행하는 메소드
    //const top = ReactDOM.findDOMNode(this).getBoundingClientRect().top; 
    //(top < 0) && 특정 액션 실행;
    return true;
  }
  page=1;
    onScroll=(e)=>{
        

        let scrollHeight=Math.max(document.documentElement.scrollHeight, document.body.scrollHeight)

        //let scrollTop=('scroll', e.srcElement.scrollingElement.scrollTop);
        let scrollTop=Math.max(document.documentElement.scrollTop, document.body.scrollTop);

        let clientHeight =Math.max(document.documentElement.clientHeight,document.body.clientHeight);
        if(scrollTop + clientHeight >=(scrollHeight-50)&& this.state.count==0){
            
            // this.setState({
            //     preItems:this.state.items,                
            //     items: this.state.preItems+1,
            //     count:this.state.count+1
            // })
            //setTimeout(()=>{
                if(!this.state.loading)
                this.getBookData(this.state.items)
            //},1000)
            //return;
        }

        console.log('scrollTop='+scrollTop+", clientHeight: "+clientHeight+", scrollHeight: "+scrollHeight)
        this.setState({scrollTop:0, count:0})
    }

    getBookData=async (start)=>{
        const {items}=this.state
        this.setState({loading:true})
        
        //let url="/book.json"
        //let url="http://localhost:9090/MyAjax/book/naverOpenApi.jsp?query=Vue";
        let url="/book/naverOpenApi.jsp?query="+encodeURIComponent("트렌드")+"&display=9&start="+items

        await axios.get(url)
             .then((res)=>{//정상적인 응답이 왔을 때
                //alert(JSON.stringify(res.data.items))
                let arr=res.data.items;
                //this.setState({books:arr});
                if(arr){
                 this.setState({
                     books:arr,
                    preItems:this.state.items,                
                    items: this.state.preItems+1,
                    count:this.state.count+1
                });
            }else{
                this.setState({loading:false})   
            }
                //callback();
             })
             .catch((err)=>{//에러 발생시
                alert('error: '+err.message)
                this.setState({loading:false})
             })
             
    }

    renderBooks=()=>{
        const {books}=this.state;
        let bks = books.map((book, i)=>{
            return (
                <Book title={book.title} image={book.image} link={book.link} key={i}></Book>
            )
        });
        return bks;
    }

    render() {
        const {books}=this.state;

        return (
            <div className="wrap">
            <div className="row py-3 m-3">
                {
                (!this.state.loading&&books&& books.length>0)? this.renderBooks():
                <div className="alert alert-danger">Loading...</div>
                }
            </div>
            </div>
        );
    }
}

export default BookApp;
