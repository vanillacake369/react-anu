import React from 'react';

export default class MyComp extends React.Component {

        state={
            count:0
        }
   
    //state는 동적으로 변경할 수 있는 데이터들을 기술한다.
    //=>변경 가능. setState()함수들을 통해서만 변경해야 함

    //props는 정적인 데이터들을 부모가 자식에게 전달할 때 사용
    //=> readonly

    //화살표 함수로 핸들러를 작성해보자.
    handlClick1=()=>{
        //alert('this 1 ='+this);//this는 현재의 객체(MyComp)
        //state의 count값을 1씩 증가
        //this.state.count= this.state.count+1; [x]
        //state를 변경하고자 할 때는 setState()를 이용해야 변경된 데이터가
        //렌더링
        this.setState({count:this.state.count+1});
    }

    //화살표함수가 아닌 경우=> this를 인식하지 못함
    //this는 전역객체(context-window)를 의미. this.setState()하면
    //전역객체에서 찾으려고 한다. setState()가 없기때문에 오류 발생
    handlClick2(){
        //alert('this 2 ='+this);
        //랜덤하게 감소시키기 1 ~ 5사이의 랜덤한 정수값을 발생시켜서
        //count값에 차감하세요 Math.random()함수 이용
        let n = Math.floor(Math.random()*5 + 1);
        //alert(n);
        this.setState({count:this.state.count-n});
    }


    render(){
        let mystyle={
            width:'200px',
            height:'200px',
            backgroundColor:'cyan',
            color:'navy',
            fontSize:'3em',
            textAlign:'center',
            borderRadius:'50%',
            margin:'3em',
            paddingTop:'1em',
            fontWeight:'bold'
        }
        return(
            <div className="container">
                    <div style={mystyle}>
                        {this.state.count}
                    </div>
                    <button className="btn                    btn-primary" onClick={this.handlClick1}>Click me</button>

                    <button className="btn                    btn-warning" onClick={this.handlClick2.bind(this)}
                    >Click me</button>
                    {/* handleClick2함수에 bind(this)함수를 이용해서
                    this객체를 붙여줘야 handleClick2함수 내에서 this 사용가능함 */}

                    {/*bind 함수는 바인드하는 함수에서 사용하는 this의 대상을 지정해주는 역할을 합니다.
                객체지향 언어에서의 일반적인 this 의 의미(현재 객체를 지칭)와는 달리 
                자바스크립트의 this 는 실행시의 (전역객체context-window) 를 말함. 따라서 this.setState하면 
                context의 setState를 찾으려고 하나 없으므로 오류 남
                (window 객체가 아니라 undefined 인 이유는 React 가 기본적으로 strict 모드에서 실행되기 때문).
                따라서 bind(this) 식으로 this현 객체를 바인드해줘야 함
                click, change 등의 이벤트 리스너를 붙여줄때마다 bind()함수를 작성하는건 귀찮은 일.
                그러나 ES6 의 화살표함수를 사용하면 이 문제를 간단히 해결할 수 있다
                화살표 함수의 this 는 외부함수(부모함수)의 this 를 상속받기 때문에 this 는 항상 일정합니다.
                 */}
            </div> 
        )
    }
}