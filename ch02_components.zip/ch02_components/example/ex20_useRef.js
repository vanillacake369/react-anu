import React,{useState, useMemo, useCallback, useRef} from 'react';
/**
 * useRef() 훅
 * => 클래스 컴포넌트의 createRef()를 함수형 컴포넌트에서는 useRef()훅을 사용한다.
 */

const getAvg=(arr)=>{
    console.log('평균값 계산 중...');
    let sum=0;
    for(let i=0;i<arr.length;i++){
        sum+=arr[i];
    }
    let avg=sum/arr.length;
    return avg;
}

const MyComp = () => {
    const [num, setNum] = useState('')
    const [list, setList] =useState([]);

    const myref = useRef(null);

    const avg=useMemo(()=>{
        return getAvg(list);
    },[list])
    //[]안의 list의 내용이 바뀌었을 때만 getAvg()함수를 호출한다.
    //useMemo훅을 사용하면 컴포넌트 내부에서 발생하는 연산을 최적화할 수 있다.
    //렌더링 과정에서 특정값이 바뀌었을 때만 연산을 실행하고, 원하는 값의 변경이 없으면 이전 결과를 다시 사용하는 방식

    const handleChange=useCallback((e)=>{
       setNum(e.target.value)
    },[])//빈 배열을 넣어주면 컴포넌트가 처음 렌더링될 때만 함수를 생성

    const handleAdd=useCallback((e)=>{
        let arr=[...list, parseInt(num)];
        setList(arr);
        setNum('')
        ///////////////////////
        myref.current.focus();
        ///////////////////////
    },[num, list])
     //num, list입력값이 바뀌거나 새로운 항목이 추가될 때 마다 함수를 생성한다.

    return (
        <div>
            <input type="text" ref={myref} name="num" value={num} onChange={handleChange}></input>
            <button className="btn" onClick={handleAdd}>등  록</button>
            <ul>
                {
                    list.map((val, i)=>(
                        <li key={i}>{val}</li> 
                    ))    
                } 
            </ul>
            {/* <h1 className="text-danger">평균값: {getAvg(list)} </h1> */}
            <h1 className="text-danger">평균값: {!isNaN(avg)&&avg} </h1>
        </div> 
    );
};

export default MyComp;