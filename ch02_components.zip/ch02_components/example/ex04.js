import React from 'react'

export default class MyComp extends React.Component{

    bgcolor='red'; //데이터
    
    state={ //데이터
        mycolor:'yellow',
        flag:false
    }

    handleClick1=()=>{
        //alert('hi this: '+this)
        this.bgcolor='orange';
        //this.bgcolor를 변경해도 화면이 다시 그려지지 않는다.
    }

    handleClick2(){
        //flag가 false이면 green, true이면 yellow로 변경해보자.
        let cr =(this.state.flag)?"yellow":"green";

        //alert('this: '+this);
        //state의 mycolor값을 green으로 변경해보세요
        //this.state.mycolor='green'; [x]
        this.setState({mycolor:cr, flag:!this.state.flag})
        //setState()가 호출되면 MyComp를 다시 렌더링한다.
    }

    render(){
        return (
            <div className="container">
                <button 
                style={{backgroundColor:this.bgcolor}}
                className="btn m-2" onClick={this.handleClick1}>좋아요1</button>

                <button 
                onClick={this.handleClick2.bind(this)}
                style={{backgroundColor:this.state.mycolor}}
                className="btn m-2">좋아요2</button>
            </div>
        )
    }
}