import React from 'react';
import BoardApp from './example/ex17_useEffect';

const App=()=>{
    return (
        <div className="container py-5">
            <BoardApp/>
        </div>
    )
}
export default App;