import React from 'react';
import MyComp from './example/ex19_useCallback';

const App=()=>{
    return (
        <div className="container py-5">
            <MyComp/>
        </div>
    )
} 
export default App;