import React from 'react';
import Counter from './example/ex14_hook'

const App=()=>{
    return (
        <div className="container py-5">
            <Counter></Counter>
        </div>
    )
}
export default App;