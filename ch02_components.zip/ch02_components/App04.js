import React from 'react';
import './App.css'
import MyComp from './example/ex04'

//class로 구현 ==> 함수형도 같이 사용
class App extends React.Component{

  render(){
    //자바스크립트 주석
    return (
    //자바스크립트 영역: 루트 엘리먼트는 반드시 1개 있어야 한다.
    <div>
      {/*JSX영역의 주석*/}
        <MyComp></MyComp>
        
    </div>
    )  
 }
}
export default App;