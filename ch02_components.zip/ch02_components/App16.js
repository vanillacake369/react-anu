import React from 'react';
import BoardApp from './example/ex16_useState';

const App=()=>{
    return (
        <div className="container py-5">
            <BoardApp mainTitle="자유 게시판"/>
        </div>
    )
}
export default App;