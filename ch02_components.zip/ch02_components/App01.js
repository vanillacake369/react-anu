import React from 'react';
import '../App.css';
import MyComp from './example/ex01';

//class로 구현 ==> 함수형도 같이 사용
class App extends React.Component{

  render(){
    //자바스크립트 주석
    return (
    //자바스크립트 영역: 루트 엘리먼트는 반드시 1개 있어야 한다.
    <div className="App">
      {/*JSX영역의 주석. MyComp에 글자색으로 사용할 속성(props)을 넘겨서 해당 글자색으로 출력되도록 해보자.*/}
        <h1>Hello React</h1>
        <MyComp title="재미있는 리액트" mycolor="blue"></MyComp>
        <MyComp title="Nice Day~~" mycolor="tomato"></MyComp>
        <MyComp title="Good Job!!" mycolor="darkgreen"></MyComp>
        <MyComp>나는 자식 컴포넌트 입니다.</MyComp>
    </div>
    )  
 }
}
export default App;