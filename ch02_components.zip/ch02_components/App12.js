import React from 'react';
import './App.css'
import BookApp from './example/ex12_axios'
//class로 구현 ==> 함수형도 같이 사용
class App extends React.Component{

  render(){
    //자바스크립트 주석
    return (
    //자바스크립트 영역: 루트 엘리먼트는 반드시 1개 있어야 한다.
    <div className="container">
      {/*JSX영역의 주석*/}
        <h1>Ajax를 이용한 도서 정보 가져오기</h1>
        <BookApp/>
    </div>
    )  
 }
}
export default App;