import React from 'react';
import Info from './example/ex15_useState'

const App=()=>{
    return (
        <div className="container py-5">
            <Info></Info>
        </div>
    )
}
export default App;